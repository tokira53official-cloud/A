# PRIME CLOUD VPS PANEL
Separate VPS panel on port 1919.

Includes: responsive landing page, animated/video background support, editable logo/name/theme, visual plan cards/categories, login/register, admin plan management, VPS creation, browser management UI, file-manager/SFTP sections, and Docker deployment files.

Default demo admin: admin / primecloud-admin. CHANGE IT before production.

Important: the VPS action routes are UI/database scaffolding. Connect them to Docker SDK/container IDs for real provisioning. Never expose Docker socket publicly; use a protected local service and enforce resource/storage quotas.
