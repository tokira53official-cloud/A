import os,sqlite3,hashlib,time
from flask import Flask,request,redirect,url_for,session,render_template,flash
from werkzeug.utils import secure_filename

app=Flask(__name__); app.secret_key=os.getenv("SECRET_KEY","CHANGE_ME")
DB="data/primecloud.db"

def db():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def init():
 c=db(); c.executescript("""CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,password TEXT,role TEXT DEFAULT 'user');
CREATE TABLE IF NOT EXISTS plans(id INTEGER PRIMARY KEY,category TEXT,name TEXT,price TEXT,ram TEXT,cpu TEXT,disk TEXT,description TEXT);
CREATE TABLE IF NOT EXISTS vps(id INTEGER PRIMARY KEY,user_id INTEGER,name TEXT,os TEXT,ram TEXT,cpu TEXT,disk TEXT,status TEXT DEFAULT 'stopped',expires_at INTEGER);""")
 defaults={"site_name":"PRIME CLOUD VPS","logo_url":"","accent":"#FFD21F","background":"#070707","background_video":"","upload_limit_mb":"500","sftp_host":"vps.primescloud.dpdns.org","sftp_port":"2022"}
 for k,v in defaults.items(): c.execute("INSERT OR IGNORE INTO settings VALUES(?,?)",(k,v))
 if not c.execute("SELECT 1 FROM plans LIMIT 1").fetchone():
  c.executemany("INSERT INTO plans(category,name,price,ram,cpu,disk,description) VALUES(?,?,?,?,?,?,?)",[
  ("Budget VPS","Dirt VPS","₹49/mo","2 GB","1 Core","20 GB","Starter VPS"),
  ("Budget VPS","Stone VPS","₹89/mo","4 GB","2 Cores","40 GB","More room for small workloads"),
  ("Premium VPS","Iron VPS","₹129/mo","6 GB","3 Cores","60 GB","Premium VPS"),
  ("Performance VPS","Gold VPS","₹249/mo","8 GB","4 Cores","100 GB","Heavy workloads")])
 if not c.execute("SELECT 1 FROM users LIMIT 1").fetchone():
  p=hashlib.sha256(os.getenv("ADMIN_PASSWORD","primecloud-admin").encode()).hexdigest()
  c.execute("INSERT INTO users(username,password,role) VALUES(?,?,?)",(os.getenv("ADMIN_USERNAME","admin"),p,"admin"))
 c.commit(); c.close()
def cfg():
 c=db(); d={r["key"]:r["value"] for r in c.execute("SELECT * FROM settings")}; c.close(); return d
@app.context_processor
def inject(): return {"cfg":cfg()}
@app.route("/")
def home():
 c=db(); p=c.execute("SELECT * FROM plans ORDER BY id").fetchall(); c.close(); return render_template("home.html",plans=p)
@app.route("/login",methods=["GET","POST"])
def login():
 if request.method=="POST":
  c=db(); u=c.execute("SELECT * FROM users WHERE username=? AND password=?",(request.form["username"],hashlib.sha256(request.form["password"].encode()).hexdigest())).fetchone(); c.close()
  if u: session.update(uid=u["id"],role=u["role"],username=u["username"]); return redirect("/dashboard")
  flash("Invalid login.")
 return render_template("login.html")
@app.route("/register",methods=["GET","POST"])
def register():
 if request.method=="POST":
  try:
   c=db(); c.execute("INSERT INTO users(username,password) VALUES(?,?)",(request.form["username"],hashlib.sha256(request.form["password"].encode()).hexdigest())); c.commit(); c.close(); return redirect("/login")
  except sqlite3.IntegrityError: flash("Username already exists.")
 return render_template("register.html")
@app.route("/logout")
def logout(): session.clear(); return redirect("/")
@app.route("/dashboard")
def dashboard():
 if "uid" not in session:return redirect("/login")
 c=db(); v=c.execute("SELECT * FROM vps WHERE user_id=?",(session["uid"],)).fetchall(); c.close(); return render_template("dashboard.html",vps=v)
@app.route("/vps/<int:i>")
def vps(i):
 if "uid" not in session:return redirect("/login")
 c=db(); v=c.execute("SELECT * FROM vps WHERE id=? AND user_id=?",(i,session["uid"])).fetchone(); c.close()
 return render_template("vps.html",v=v) if v else ("Not found",404)
@app.route("/vps/<int:i>/action/<a>",methods=["POST"])
def action(i,a):
 if "uid" not in session:return redirect("/login")
 status={"start":"running","stop":"stopped","restart":"running"}.get(a)
 if status:
  c=db(); c.execute("UPDATE vps SET status=? WHERE id=? AND user_id=?",(status,i,session["uid"])); c.commit(); c.close()
 return redirect("/vps/"+str(i))
@app.route("/admin")
def admin():
 if session.get("role")!="admin":return redirect("/")
 c=db(); plans=c.execute("SELECT * FROM plans").fetchall(); users=c.execute("SELECT * FROM users").fetchall(); vps=c.execute("SELECT * FROM vps").fetchall(); c.close()
 return render_template("admin.html",plans=plans,users=users,vps=vps)
@app.route("/admin/settings",methods=["POST"])
def settings_save():
 if session.get("role")!="admin":return "Forbidden",403
 c=db()
 for k in ["site_name","logo_url","accent","background","background_video","upload_limit_mb","sftp_host","sftp_port"]:
  c.execute("INSERT OR REPLACE INTO settings VALUES(?,?)",(k,request.form.get(k,"")))
 c.commit(); c.close(); return redirect("/admin")
@app.route("/admin/plan",methods=["POST"])
def plan():
 if session.get("role")!="admin":return "Forbidden",403
 c=db(); c.execute("INSERT INTO plans(category,name,price,ram,cpu,disk,description) VALUES(?,?,?,?,?,?,?)",tuple(request.form.get(x,"") for x in ["category","name","price","ram","cpu","disk","description"])); c.commit(); c.close(); return redirect("/admin")
@app.route("/admin/plan/<int:i>/delete",methods=["POST"])
def delplan(i):
 if session.get("role")!="admin":return "Forbidden",403
 c=db(); c.execute("DELETE FROM plans WHERE id=?",(i,)); c.commit(); c.close(); return redirect("/admin")
@app.route("/admin/vps",methods=["POST"])
def create_vps():
 if session.get("role")!="admin":return "Forbidden",403
 c=db(); c.execute("INSERT INTO vps(user_id,name,os,ram,cpu,disk,expires_at) VALUES(?,?,?,?,?,?,?)",
 (request.form["user_id"],request.form["name"],request.form["os"],request.form["ram"],request.form["cpu"],request.form["disk"],int(time.time())+int(request.form.get("days",30))*86400)); c.commit(); c.close(); return redirect("/admin")
init()
app.run(host="0.0.0.0",port=1919)
